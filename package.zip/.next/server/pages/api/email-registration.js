"use strict";
(() => {
var exports = {};
exports.id = 967;
exports.ids = [967];
exports.modules = {

/***/ 6920:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
function handler(req, res) {
    const { method  } = req;
    //Access our data
    //extract data
    if (method === "POST") {
        const { email , name , subject , text , eventId  } = req.body;
        res.status(200).json({
            message: `You have been registered succesfully with the email: ${email}
             ${eventId}
             ${name},
             ${subject},
             ${text}
             
             `
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6920));
module.exports = __webpack_exports__;

})();