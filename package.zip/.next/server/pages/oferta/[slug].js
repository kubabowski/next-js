"use strict";
(() => {
var exports = {};
exports.id = 678;
exports.ids = [678];
exports.modules = {

/***/ 2768:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _api_db__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1009);
/* harmony import */ var _components_Modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1774);





const OfferDetails = ({ offers  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { slug  } = router.query;
    // Find the offer with the matching slug
    const offer = offers.find((offer)=>{
        console.log("Comparing:", offer.slug, slug);
        return offer.slug === slug;
    });
    if (!offer) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Offers not found"
        });
    }
    const { title , offerdesc , subtitle1 , subtitle2 , subtitle3 , subtitle4 , subtitle5 , subtitle6 , subtitle7 , subdesc1 , subdesc2 , subdesc3 , subdesc4 , subdesc5 , subdesc6 , subdesc7 , details  } = offer;
    const goBack = ()=>{
        router.back();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "container mx-auto text-center mt-[3%] relative mb-10",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "sm:w-[50%] mx-auto",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-2xl text-center text-white align-bottom mb-5",
                        children: [
                            title,
                            " "
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: offerdesc
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-10 font-extralight"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subtitle1
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-2 font-medium tracking-wider"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subdesc1
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-10 font-extralight"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subtitle2
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-2 font-medium tracking-wider"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subdesc2
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-10 font-extralight"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subtitle3
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-2 font-medium tracking-wider"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subdesc3
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-10 font-extralight"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subtitle4
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-2 font-medium tracking-wider"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subdesc4
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-10 font-extralight"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subtitle5
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-2 font-medium tracking-wider"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subdesc5
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-10 font-extralight"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subtitle6
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-2 font-medium tracking-wider"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subdesc6
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-10 font-extralight"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subtitle7
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-2 font-medium tracking-wider"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: subdesc7
                        },
                        className: "text-white text-md align-bottom mx-auto sm:w-[90%] mb-10 font-extralight"
                    })
                ]
            }),
            details && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Modal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                customClass: "font-medium text-lg tracking-wider",
                className: "text-white mb-5",
                text: details,
                label: `SZCZEGÓŁY`
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                className: "text-white absolute top-0 left-0 flex items-center",
                onClick: goBack,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mr-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                            style: {
                                fill: "white",
                                width: "40px"
                            },
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 50 50",
                            id: "arrow-left",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "m5.414 24 6.293-6.293-1.414-1.414L1.586 25l8.707 8.707 1.414-1.414L5.414 26H49v-2z"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: "wr\xf3ć"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OfferDetails);
async function getServerSideProps() {
    const offers = await (0,_api_db__WEBPACK_IMPORTED_MODULE_3__/* .getOffers */ .Rg)();
    return {
        props: {
            offers
        }
    };
}


/***/ }),

/***/ 2418:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9931:
/***/ ((module) => {

module.exports = require("react-modal");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,9,774], () => (__webpack_exec__(2768)));
module.exports = __webpack_exports__;

})();