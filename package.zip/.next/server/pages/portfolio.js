(() => {
var exports = {};
exports.id = 371;
exports.ids = [371];
exports.modules = {

/***/ 633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ portfolio),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-18-image-lightbox"
const external_react_18_image_lightbox_namespaceObject = require("react-18-image-lightbox");
var external_react_18_image_lightbox_default = /*#__PURE__*/__webpack_require__.n(external_react_18_image_lightbox_namespaceObject);
// EXTERNAL MODULE: ./node_modules/react-18-image-lightbox/style.css
var style = __webpack_require__(3964);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/Lightbox.js





const Lightboxv1 = ({ portfolio  })=>{
    const [rowCols, setRowCols] = (0,external_react_.useState)([]);
    const [photoIndex, setPhotoIndex] = (0,external_react_.useState)(0);
    const [isOpen, setIsOpen] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const imagesQuantity = portfolio.length;
        const rowCols = Array.from({
            length: imagesQuantity
        }, ()=>[
                randomNumber(4),
                randomNumber(3),
                randomNumber(10)
            ]);
        setRowCols(rowCols);
    }, [
        portfolio
    ]);
    const randomNumber = (limit)=>Math.floor(Math.random() * limit) + 1;
    const images = portfolio.map((item, index)=>({
            src: `/${item.photo_url}`,
            caption: item.photo_desc,
            index
        }));
    const openLightbox = (index)=>{
        setPhotoIndex(index);
        setIsOpen(true);
    };
    const goToPrevious = ()=>{
        setPhotoIndex((photoIndex + images.length - 1) % images.length);
    };
    const goToNext = ()=>{
        setPhotoIndex((photoIndex + 1) % images.length);
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "container mx-auto",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "wrapper",
                children: rowCols.length > 0 && portfolio.map((item, index)=>/*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: `wrapper-images height-${rowCols[index][0]} width-${rowCols[index][1]} padding-${rowCols[index][2]}`,
                        children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                            src: `/${item.photo_url}`,
                            alt: item.photo_desc,
                            onClick: ()=>openLightbox(index),
                            className: "portfolio-img"
                        })
                    }, index))
            }),
            isOpen && /*#__PURE__*/ jsx_runtime.jsx((external_react_18_image_lightbox_default()), {
                mainSrc: images[photoIndex].src,
                nextSrc: images[(photoIndex + 1) % images.length].src,
                prevSrc: images[(photoIndex + images.length - 1) % images.length].src,
                onCloseRequest: ()=>setIsOpen(false),
                onMovePrevRequest: ()=>goToPrevious(),
                onMoveNextRequest: ()=>goToNext(),
                enableZoom: false,
                imageCaption: images[photoIndex].caption
            })
        ]
    });
};
/* harmony default export */ const Lightbox = (Lightboxv1);

// EXTERNAL MODULE: ./pages/api/db.js
var db = __webpack_require__(1009);
;// CONCATENATED MODULE: ./pages/portfolio.jsx




const Portfolio = ({ portfolio  })=>{
    return /*#__PURE__*/ jsx_runtime.jsx(Lightbox, {
        portfolio: portfolio
    });
};
async function getServerSideProps() {
    const portfolio = await (0,db/* getPortfolio */.xp)();
    return {
        props: {
            portfolio
        }
    };
}
/* harmony default export */ const portfolio = (Portfolio);


/***/ }),

/***/ 3964:
/***/ (() => {



/***/ }),

/***/ 2418:
/***/ ((module) => {

"use strict";
module.exports = require("mysql2/promise");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,636,260,9], () => (__webpack_exec__(633)));
module.exports = __webpack_exports__;

})();