(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4989:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/instagram.ca323260.svg","height":50,"width":50,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 1626:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./styles/globals.scss
var globals = __webpack_require__(3716);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/Navbar.jsx




const NAV_LINKS = [
    {
        name: "O mnie",
        url: "/o-mnie"
    },
    {
        name: "Portfolio",
        url: "/portfolio"
    },
    {
        name: "Oferta",
        url: "/oferta"
    },
    {
        name: "Blog",
        url: "/blog"
    },
    {
        name: "Kontakt",
        url: "/kontakt"
    }
];
const Navbar = (props)=>{
    const [nav, setNav] = (0,external_react_.useState)(false);
    const [color, setColor] = (0,external_react_.useState)("transparent");
    const [navPadding, setNavPadding] = (0,external_react_.useState)("h-[90px]");
    const { pathname  } = (0,router_.useRouter)();
    const handleNav = ()=>setNav((prevNav)=>!prevNav);
    const currentRoute = pathname;
    (0,external_react_.useEffect)(()=>{
        const changeColor = ()=>{
            if (window.scrollY > 30) {
                setColor("#000000e6");
                setNavPadding("h-[70px]");
                return;
            }
            setColor("transparent");
            setNavPadding("h-[90px]");
        };
        window.addEventListener("scroll", changeColor);
    }, []);
    props.appNavHeight;
    const ref = (0,external_react_.useRef)(null);
    const [navHeight, setNavHeight] = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        setNavHeight(()=>ref.current.clientHeight);
    }, [
        navHeight
    ]);
    props.getNavHeight(navHeight);
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        id: "navBarID",
        style: {
            backgroundColor: `${color}`
        },
        className: `fixed top-0 left-0 w-full z-10 ease`,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            ref: ref,
            className: `${navPadding}  container m-auto flex justify-between items-center text-white mx-auto duration-300`,
            children: [
                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "logo py-1 text-md uppercase tracking-wider",
                        children: [
                            "Kalina Opalińska",
                            props.title
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime.jsx("ul", {
                    className: "hidden md:flex",
                    children: NAV_LINKS.map(({ name , url  }, index)=>/*#__PURE__*/ jsx_runtime.jsx("li", {
                            className: `text-sm ${currentRoute == url ? "active" : ""} mx-4 py-1 uppercase`,
                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: url,
                                children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                    className: "font-extralight",
                                    children: name
                                })
                            })
                        }, index))
                }),
                /*#__PURE__*/ jsx_runtime.jsx("a", {
                    href: "#",
                    className: "text-white md:hidden",
                    onClick: handleNav,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
                        viewBox: "0 0 50 80",
                        width: "40",
                        height: "20",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("rect", {
                                fill: "white",
                                width: "100",
                                height: "5"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("rect", {
                                fill: "white",
                                y: "30",
                                width: "100",
                                height: "5"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("rect", {
                                fill: "white",
                                y: "60",
                                width: "100",
                                height: "5"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: nav ? "absolute top-0 right-0 bottom-0 flex justify-center items-center w-full h-screen bg-black text-center ease-in duration-300" : " md:hidden absolute top-0 right-[-100%] bottom-0 flex justify-center items-center w-full h-screen bg-black text-center ease-in duration-300",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("ul", {
                            children: NAV_LINKS.map(({ name , url  }, index)=>/*#__PURE__*/ jsx_runtime.jsx("li", {
                                    className: "p-4 text-lg hover:text-gray-500 ease-in-out duration-150 ",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: url,
                                        onClick: handleNav,
                                        children: name
                                    })
                                }, index))
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("a", {
                            href: "#",
                            className: "text-white md:hidden text-xl absolute top-[4%] right-[7%]",
                            onClick: handleNav,
                            children: /*#__PURE__*/ jsx_runtime.jsx("svg", {
                                width: "40",
                                height: "40",
                                viewBox: "0 0 40 40",
                                children: /*#__PURE__*/ jsx_runtime.jsx("path", {
                                    d: "M 10,10 L 30,30 M 30,10 L 10,30",
                                    stroke: "white",
                                    strokeWidth: "1"
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_Navbar = (Navbar);

;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
// EXTERNAL MODULE: ./images/instagram.svg
var instagram = __webpack_require__(4989);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./images/logo.svg
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.c5ca41e0.svg","height":1062,"width":590,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./components/Modal.js
var Modal = __webpack_require__(1774);
;// CONCATENATED MODULE: ./components/Footer.jsx






const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("footer", {
        className: "pb-10 z-20 relative",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "footer-line"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "container flex w-[100%] mx-auto justify-between items-end pt-10",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex items-center w-[100%]",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: logo,
                                alt: "logo",
                                className: "logo-footer",
                                width: "120"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col w-[100%]",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            className: "ml-20",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "text-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "mb-3",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "text-sm text-white font-medium",
                                                            children: "Dane firmy"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                            href: "mailto: kontakt@kalinaopalinska.pl",
                                                            className: "text-sm text-white font-extralight",
                                                            children: "kontakt@kalinaopalinska.pl"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                            href: "tel: +48 730 737 974",
                                                            className: "text-sm text-white font-extralight",
                                                            children: "730 737 974"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                            className: "text-sm text-white font-extralight",
                                                            children: "Wrocław"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "flex justify-center",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                            href: "https://instagram.com/kalinaopalinska",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                                src: instagram/* default */.Z,
                                                                alt: "insta",
                                                                className: "about-me-img",
                                                                width: "30"
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "ml-20 text-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "mb-3",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "text-sm text-white font-medium",
                                                        children: "Godziny otwarcia"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "text-sm text-white font-extralight",
                                                        children: "Pon - Ndz"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "text-sm text-white font-extralight",
                                                        children: "Dostępność według um\xf3wionych spotkań"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "text-sm text-white font-extralight",
                                                        children: "Dojazd do klienta"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex justify-between container mt-10 ml-20",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                className: "text-sm text-gray-300 font-extralight",
                                                children: "Wszelkie prawa zastrzeżone \xa9 2023 Kalina Opalińska"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx(Modal/* default */.Z, {
                                                    customClass: "text-sm text-white font-extralight mr-4",
                                                    className: "",
                                                    text: "test test",
                                                    label: `Polityka prywatności`
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx(Modal/* default */.Z, {
                                                    customClass: "text-sm text-white font-extralight mr-4",
                                                    className: "",
                                                    text: "test test",
                                                    label: `Regulamin`
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx(Modal/* default */.Z, {
                                                    customClass: "text-sm text-white font-extralight",
                                                    className: "",
                                                    text: "test test",
                                                    label: `Klauzula poufności`
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                className: "text-sm text-gray-300 font-extralight",
                                                children: [
                                                    "Wsparcie i realizacja ",
                                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        className: "animated-underline",
                                                        href: "https://www.linkedin.com/in/kuba-kacper-jakubowski-/",
                                                        children: "Kuba Jakubowski"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./pages/_app.js








function MyApp({ Component , pageProps  }) {
    const [navHeight, setNavHeight] = external_react_default().useState();
    const { pathname  } = (0,router_.useRouter)();
    const currentRoute = pathname.replace("/", "page");
    const getNavHeight = (height)=>{
        external_react_default().useEffect(()=>{
            setNavHeight(height);
        });
    };
    const [navPadding, setNavPadding] = external_react_default().useState(0);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("title", {
                        children: "Kalina Opalińska"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx(components_Navbar, {
                getNavHeight: getNavHeight
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: `${currentRoute} home-gradient`,
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        id: "bg-shadow"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        id: "scrollMargin",
                        style: {
                            height: navHeight
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "min-h-[90vh] relative",
                        children: /*#__PURE__*/ jsx_runtime.jsx(Component, {
                            ...pageProps
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx(components_Footer, {})
                ]
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 3716:
/***/ (() => {



/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9931:
/***/ ((module) => {

"use strict";
module.exports = require("react-modal");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,636,664,260,152,774], () => (__webpack_exec__(1626)));
module.exports = __webpack_exports__;

})();